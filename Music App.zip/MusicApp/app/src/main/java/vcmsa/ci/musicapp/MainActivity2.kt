package vcmsa.ci.musicapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.RatingBar


class MainActivity2 : AppCompatActivity() {
    @SuppressLint("MissingInflatedId", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)

        val ratingBarProduct1: RatingBar = findViewById(R.id.ratingBar)
        val ratingBar2: RatingBar = findViewById(R.id.ratingBar2)
        val ratingBar3: RatingBar = findViewById(R.id.ratingBar3)
        val ratingBar4: RatingBar = findViewById(R.id.ratingBar4)
        val calculateButton: Button = findViewById(R.id.calcAverage)
        val averageTextView: TextView = findViewById(R.id.songRatings)

        calculateButton.setOnClickListener {
            val rating1 = ratingBarProduct1.rating
            val rating2 = ratingBar2.rating
            val ratingBar = ratingBar3.rating
            val rating4 = ratingBar4.rating

            val totalRating = rating1 + rating2
            val numberOfRatings = 4 // 4 songs are being rated
            val average = totalRating / numberOfRatings

            averageTextView.text = "Average Rating: %.1f".format(average)


            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }
        }
    }
}