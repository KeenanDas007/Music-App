package vcmsa.ci.musicapp


import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.TextView
import android.widget.EditText
import android.widget.Button



@Suppress("NAME_SHADOWING", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE")
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val objectNames = arrayOf("songName1", "songName2", "songName3", "songName4")
        mutableListOf<Int>() // Store individual ratings

        var objectNameTextView: TextView
        var ratingInput: EditText
        var exitButton: Button
        var nextButton: Button


        @SuppressLint("MissingSuperCall", "CutPasteId", "MissingInflatedId")
        fun onCreate(savedInstanceState: Bundle?) {

            setContentView(R.layout.activity_main)

            objectNameTextView = findViewById(R.id.songName1)
            objectNameTextView = findViewById(R.id.songName2)
            objectNameTextView = findViewById(R.id.songName3)
            objectNameTextView = findViewById(R.id.songName4)
            ratingInput = findViewById(R.id.ratingBar)
            ratingInput = findViewById(R.id.ratingBar2)
            ratingInput = findViewById(R.id.ratingBar3)
            ratingInput = findViewById(R.id.ratingBar4)
            exitButton = findViewById(R.id.exitButton)
            nextButton = findViewById(R.id.nextButtonId)


            // Display the first object to rate (or a specific one)
            objectNameTextView.text = objectNames[0]

            val addtoplaylist: Button = findViewById(R.id.playBtn)

            addtoplaylist.setOnClickListener {
            }
//exit button
            val exitButton: Button = findViewById(R.id.exitButton)
            exitButton.setOnClickListener {
            }
            //link to next page
            val nextButton: Button = findViewById(R.id.nextButtonId)
            nextButton.setOnClickListener {

            nextButton.setOnClickListener {
                val intent = Intent(this, MainActivity2::class.java)
                startActivity(intent)



                ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                    val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                    v.setPadding(
                        systemBars.left,
                        systemBars.top,
                        systemBars.right,
                        systemBars.bottom
                    )
                    insets
                }
            }
        }
    }
    }
    }